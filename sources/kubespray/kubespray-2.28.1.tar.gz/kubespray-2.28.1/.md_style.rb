all
exclude_rule 'MD013'
exclude_rule 'MD029'
rule 'MD007', :indent => 2
